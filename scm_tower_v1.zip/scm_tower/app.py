"""
SCM Supply Control Tower
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
실행: streamlit run app.py
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import io

# ── 내부 모듈 ──
from data.sample_data import generate_monthly_data, get_latest_snapshot, generate_action_tracker
from components.styles import (
    PREMIUM_CSS, RISK_COLOR_MAP, RISK_BG_MAP,
    risk_badge_html, kpi_card_html, insight_card_html,
    section_card_start, section_card_end,
)
from components.charts import (
    plan_vs_actual_trend, risk_heatmap, inventory_scatter,
    achievement_bar, stockout_timeline, inv_group_bar,
    sku_monthly_detail, inv_days_gauge,
)

# ── 페이지 설정 ─────────────────────────────────────────────────
st.set_page_config(
    page_title="SCM Supply Control Tower",
    page_icon="🏗️",
    layout="wide",
    initial_sidebar_state="expanded",
)
st.markdown(PREMIUM_CSS, unsafe_allow_html=True)

# ── 임계값 설정 (Session State) ──────────────────────────────────
if "thresholds" not in st.session_state:
    st.session_state.thresholds = {
        "critical": 20, "warning": 30, "caution": 60,
        "stable": 60, "excess": 120, "severe_excess": 180,
    }
if "df" not in st.session_state:
    with st.spinner("데이터 로딩 중..."):
        st.session_state.df = generate_monthly_data(months_back=6)
if "actions" not in st.session_state:
    st.session_state.actions = generate_action_tracker()

df      = st.session_state.df
actions = st.session_state.actions
latest  = get_latest_snapshot(df)
thr     = st.session_state.thresholds
TODAY   = datetime.today().strftime("%Y-%m-%d")


# ══════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════
with st.sidebar:
    st.markdown("""
    <div class="sidebar-logo">
        <div class="sidebar-logo-mark">🏗️</div>
        <div>
            <div class="sidebar-logo-text">SCM Control Tower</div>
            <div class="sidebar-logo-sub">Supply Intelligence</div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    page = st.radio(
        "Navigation",
        options=[
            "📊 Executive Overview",
            "⚠️ Supply Risk Monitoring",
            "📦 Inventory Analytics",
            "📈 Demand & Sales Analysis",
            "🚚 Supply & Production",
            "🔍 SKU Detail Explorer",
            "🤖 Forecast & AI Prediction",
            "✅ Action Tracker",
            "⚙️ Master Data / Settings",
        ],
        label_visibility="collapsed",
    )

    st.markdown("---")
    st.markdown(f"<div style='font-size:11px;color:#9CA3AF'>기준일: {TODAY}</div>", unsafe_allow_html=True)

    # 데이터 업로드
    st.markdown("**데이터 업로드**")
    uploaded = st.file_uploader("Excel / CSV", type=["xlsx","csv"], label_visibility="collapsed")
    if uploaded:
        try:
            if uploaded.name.endswith(".csv"):
                new_df = pd.read_csv(uploaded)
            else:
                new_df = pd.read_excel(uploaded)
            new_df["date"] = pd.to_datetime(new_df["date"])
            st.session_state.df = new_df
            df = new_df
            latest = get_latest_snapshot(df)
            st.success(f"✅ {len(new_df):,}행 로드 완료")
        except Exception as e:
            st.error(f"파일 오류: {e}")

    # 글로벌 필터
    st.markdown("**필터**")
    sel_groups = st.multiselect(
        "제품군", options=sorted(df["product_group"].unique()),
        default=sorted(df["product_group"].unique()), label_visibility="collapsed",
    )
    sel_bu = st.multiselect(
        "사업부", options=sorted(df["business_unit"].unique()),
        default=sorted(df["business_unit"].unique()), label_visibility="collapsed",
    )

# ── 글로벌 필터 적용 ──────────────────────────────────────────────
df_f     = df[df["product_group"].isin(sel_groups) & df["business_unit"].isin(sel_bu)]
latest_f = df_f[df_f["date"] == df_f["date"].max()].copy()


# ══════════════════════════════════════════
# PAGE 1: EXECUTIVE OVERVIEW
# ══════════════════════════════════════════
if page == "📊 Executive Overview":
    st.markdown("""
    <div class="page-header">
        <div>
            <div class="page-title">Executive Overview</div>
            <div class="page-sub">Supply chain health at a glance — 3-second risk assessment</div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # KPI 행
    total_plan   = latest_f["plan_amt"].sum()
    total_actual = latest_f["actual_amt"].sum()
    total_inv    = latest_f["end_inv_amt"].sum()
    avg_inv_days = latest_f["inv_days"].replace(999, np.nan).mean()
    critical_cnt = (latest_f["risk_level"] == "Critical").sum()
    warning_cnt  = (latest_f["risk_level"] == "Warning").sum()
    delay_cnt    = (latest_f["supply_delay_days"] > 0).sum()
    excess_amt   = latest_f[latest_f["inv_days"] > thr["excess"]]["end_inv_amt"].sum()
    achieve_rate = total_actual / total_plan * 100 if total_plan > 0 else 0

    cols = st.columns(8, gap="small")
    kpis = [
        ("달성률", f"{achieve_rate:.1f}%", "", "success" if achieve_rate >= 80 else "warning" if achieve_rate >= 60 else "danger"),
        ("전체 재고", f"{total_inv:.0f}억", "기말재고 기준", "blue"),
        ("평균 재고일수", f"{avg_inv_days:.0f}일", "전체 SKU 평균", "warning" if avg_inv_days < 30 else ""),
        ("Critical SKU", f"{critical_cnt}", "즉시 조치 필요", "danger"),
        ("Warning SKU", f"{warning_cnt}", "당일 모니터링", "warning"),
        ("공급 지연", f"{delay_cnt}", "SKU 수", "warning" if delay_cnt > 0 else ""),
        ("과잉재고", f"{excess_amt:.0f}억", f">{thr['excess']}일 초과", "blue"),
        ("실제 매출", f"{total_actual:.0f}억", f"계획 {total_plan:.0f}억", ""),
    ]
    for col, (label, val, sub, cls) in zip(cols, kpis):
        with col:
            st.markdown(kpi_card_html(label, val, sub, cls), unsafe_allow_html=True)

    st.markdown("<div style='height:20px'></div>", unsafe_allow_html=True)

    # 2열 레이아웃
    col_left, col_right = st.columns([3, 2], gap="medium")

    with col_left:
        st.markdown(section_card_start("📊 Plan vs Actual vs Supply vs Ending Inventory"), unsafe_allow_html=True)
        st.plotly_chart(plan_vs_actual_trend(df_f), use_container_width=True, config={"displayModeBar": False})
        st.markdown(section_card_end(), unsafe_allow_html=True)

        st.markdown(section_card_start("🌡️ Supply Risk Heatmap — 제품군 × 리스크 등급"), unsafe_allow_html=True)
        st.plotly_chart(risk_heatmap(latest_f), use_container_width=True, config={"displayModeBar": False})
        st.markdown(section_card_end(), unsafe_allow_html=True)

    with col_right:
        # Executive Summary
        st.markdown(section_card_start("🧭 Executive Summary"), unsafe_allow_html=True)

        critical_skus = latest_f[latest_f["risk_level"] == "Critical"]["product_name"].tolist()
        fast_skus = latest_f[latest_f["fast_mover"] == True]["product_name"].tolist()
        slow_skus = latest_f[latest_f["slow_mover"] == True]["product_name"].tolist()
        excess_skus = latest_f[latest_f["inv_days"] > thr["excess"]]["product_name"].tolist()

        if critical_skus:
            st.markdown(insight_card_html(
                f"🚨 Critical 위험 {len(critical_skus)}건 — 즉시 조치",
                " · ".join(critical_skus[:4]) + ("..." if len(critical_skus) > 4 else ""),
                "critical"
            ), unsafe_allow_html=True)
        if fast_skus:
            st.markdown(insight_card_html(
                f"📈 수요 급증 {len(fast_skus)}건 — 재고 모니터링",
                " · ".join(fast_skus[:4]),
                "warning"
            ), unsafe_allow_html=True)
        if slow_skus:
            st.markdown(insight_card_html(
                f"📉 판매 부진 {len(slow_skus)}건 — 매출 상향 필요",
                " · ".join(slow_skus[:4]),
                "info"
            ), unsafe_allow_html=True)
        if excess_skus:
            st.markdown(insight_card_html(
                f"📦 과잉재고 {len(excess_skus)}건 — 공급 조정 검토",
                " · ".join(excess_skus[:4]),
                "info"
            ), unsafe_allow_html=True)
        if achieve_rate < 70:
            st.markdown(insight_card_html(
                f"⚠️ 전체 달성률 {achieve_rate:.1f}% — 매출 갭 {(total_plan-total_actual):.0f}억",
                "마케팅 매출 상향 대책 즉시 수립 요청",
                "warning"
            ), unsafe_allow_html=True)
        st.markdown(section_card_end(), unsafe_allow_html=True)

        # 품절 예상 TOP 10
        st.markdown(section_card_start("⏱️ 품절 예상 TOP 10"), unsafe_allow_html=True)
        st.plotly_chart(stockout_timeline(df_f), use_container_width=True, config={"displayModeBar": False})
        st.markdown(section_card_end(), unsafe_allow_html=True)


# ══════════════════════════════════════════
# PAGE 2: SUPPLY RISK MONITORING
# ══════════════════════════════════════════
elif page == "⚠️ Supply Risk Monitoring":
    st.markdown("""<div class="page-header"><div>
        <div class="page-title">Supply Risk Monitoring</div>
        <div class="page-sub">SKU별 공급 리스크 현황 및 조치 우선순위</div>
    </div></div>""", unsafe_allow_html=True)

    # 필터
    fcols = st.columns([2,2,2,2,2], gap="small")
    with fcols[0]:
        f_risk = st.multiselect("리스크 등급", ["Critical","Warning","Caution","Stable","Excess"],
                                default=["Critical","Warning","Caution","Stable","Excess"])
    with fcols[1]:
        f_supply = st.multiselect("공급 유형", sorted(df_f["supply_type"].unique()),
                                  default=list(df_f["supply_type"].unique()))
    with fcols[2]:
        f_inv_max = st.slider("재고일수 최대", 0, 400, 400, step=10)
    with fcols[3]:
        f_delay = st.checkbox("공급 지연 있는 SKU만", value=False)
    with fcols[4]:
        search = st.text_input("SKU/제품명 검색", placeholder="검색...")

    # 테이블 데이터
    tbl = latest_f[latest_f["risk_level"].isin(f_risk)].copy()
    tbl = tbl[tbl["supply_type"].isin(f_supply)]
    tbl = tbl[tbl["inv_days"] <= f_inv_max]
    if f_delay:
        tbl = tbl[tbl["supply_delay_days"] > 0]
    if search:
        mask = (tbl["sku_code"].str.contains(search, case=False) |
                tbl["product_name"].str.contains(search, case=False))
        tbl = tbl[mask]

    tbl = tbl.sort_values(["risk_level", "inv_days"], key=lambda x: x.map(
        {"Critical":0,"Warning":1,"Caution":2,"Stable":3,"Excess":4}) if x.name=="risk_level" else x
    )

    # KPI 요약 행
    c1,c2,c3,c4,c5 = st.columns(5, gap="small")
    for col, (lbl, val, cls) in zip(
        [c1,c2,c3,c4,c5],
        [
            ("조회 SKU", f"{len(tbl)}개", ""),
            ("Critical", f"{(tbl['risk_level']=='Critical').sum()}개", "danger"),
            ("Warning",  f"{(tbl['risk_level']=='Warning').sum()}개", "warning"),
            ("공급지연", f"{(tbl['supply_delay_days']>0).sum()}개", "warning"),
            ("과잉재고", f"{(tbl['inv_days']>thr['excess']).sum()}개", "blue"),
        ]
    ):
        col.markdown(kpi_card_html(lbl, val, "", cls), unsafe_allow_html=True)

    st.markdown("<div style='height:16px'></div>", unsafe_allow_html=True)

    # 리스크 테이블
    display_cols = {
        "sku_code": "SKU",
        "product_name": "제품명",
        "product_group": "제품군",
        "plan_amt": "계획(억)",
        "actual_amt": "실적(억)",
        "achievement_rate": "달성률(%)",
        "end_inv_amt": "기말재고(억)",
        "inv_days": "재고일수",
        "supply_delay_days": "지연일수",
        "expected_stockout_date": "예상품절일",
        "risk_level": "리스크",
    }
    tbl_show = tbl[list(display_cols.keys())].rename(columns=display_cols)
    tbl_show["계획(억)"] = tbl_show["계획(억)"].round(2)
    tbl_show["실적(억)"] = tbl_show["실적(억)"].round(2)
    tbl_show["기말재고(억)"] = tbl_show["기말재고(억)"].round(1)

    st.dataframe(
        tbl_show,
        use_container_width=True,
        height=420,
        column_config={
            "리스크": st.column_config.TextColumn("리스크"),
            "달성률(%)": st.column_config.NumberColumn("달성률(%)", format="%.1f%%"),
            "재고일수": st.column_config.NumberColumn("재고일수", format="%d일"),
            "지연일수": st.column_config.NumberColumn("지연일수", format="%d일"),
        },
    )

    # 다운로드
    excel_buf = io.BytesIO()
    tbl_show.to_excel(excel_buf, index=False)
    st.download_button("📥 Excel 다운로드", excel_buf.getvalue(),
                       f"supply_risk_{TODAY}.xlsx", "application/vnd.ms-excel")


# ══════════════════════════════════════════
# PAGE 3: INVENTORY ANALYTICS
# ══════════════════════════════════════════
elif page == "📦 Inventory Analytics":
    st.markdown("""<div class="page-header"><div>
        <div class="page-title">Inventory Analytics</div>
        <div class="page-sub">재고 건강도 분석 — 과잉·부족·회전율</div>
    </div></div>""", unsafe_allow_html=True)

    tab1, tab2, tab3 = st.tabs(["📊 재고 개요", "🔴 과잉재고 TOP 20", "📉 저재고 위험 TOP 20"])

    with tab1:
        c1, c2 = st.columns(2, gap="medium")
        with c1:
            st.markdown(section_card_start("제품군별 기말재고 금액"), unsafe_allow_html=True)
            st.plotly_chart(inv_group_bar(latest_f), use_container_width=True, config={"displayModeBar": False})
            st.markdown(section_card_end(), unsafe_allow_html=True)
        with c2:
            st.markdown(section_card_start("재고일수 vs 매출금액 산점도"), unsafe_allow_html=True)
            st.caption("버블 크기 = 재고금액 · 색상 = 리스크 등급")
            st.plotly_chart(inventory_scatter(df_f), use_container_width=True, config={"displayModeBar": False})
            st.markdown(section_card_end(), unsafe_allow_html=True)

        st.markdown(section_card_start("재고 건강도 분포"), unsafe_allow_html=True)
        risk_dist = latest_f["risk_level"].value_counts().reset_index()
        risk_dist.columns = ["리스크", "SKU 수"]
        cols = st.columns(len(risk_dist), gap="small")
        for col, (_, row) in zip(cols, risk_dist.iterrows()):
            color = RISK_COLOR_MAP.get(row["리스크"], "#6B7280")
            bg    = RISK_BG_MAP.get(row["리스크"], "#F3F4F6")
            col.markdown(
                f'<div class="kpi-card" style="border-left:3px solid {color};background:{bg}">'
                f'<div class="kpi-label">{row["리스크"]}</div>'
                f'<div class="kpi-value" style="color:{color}">{row["SKU 수"]}</div>'
                f'<div class="kpi-sub">SKU</div></div>',
                unsafe_allow_html=True
            )
        st.markdown(section_card_end(), unsafe_allow_html=True)

    with tab2:
        excess = latest_f[latest_f["inv_days"] > thr["excess"]].sort_values("end_inv_amt", ascending=False).head(20)
        st.markdown(f"**과잉재고 ({len(excess)}건) — 재고일수 {thr['excess']}일 초과**")
        st.dataframe(
            excess[["sku_code","product_name","product_group","inv_days","end_inv_amt","actual_amt"]].rename(columns={
                "sku_code":"SKU","product_name":"제품명","product_group":"제품군",
                "inv_days":"재고일수","end_inv_amt":"재고금액(억)","actual_amt":"월매출(억)",
            }),
            use_container_width=True, height=360,
        )

    with tab3:
        low_inv = latest_f[latest_f["inv_days"] < thr["warning"]].sort_values("inv_days").head(20)
        st.markdown(f"**저재고 위험 ({len(low_inv)}건) — 재고일수 {thr['warning']}일 미만**")
        st.dataframe(
            low_inv[["sku_code","product_name","product_group","inv_days","end_inv_amt","expected_stockout_date","risk_level"]].rename(columns={
                "sku_code":"SKU","product_name":"제품명","product_group":"제품군",
                "inv_days":"재고일수","end_inv_amt":"재고금액(억)",
                "expected_stockout_date":"예상품절일","risk_level":"리스크",
            }),
            use_container_width=True, height=360,
        )


# ══════════════════════════════════════════
# PAGE 4: DEMAND & SALES ANALYSIS
# ══════════════════════════════════════════
elif page == "📈 Demand & Sales Analysis":
    st.markdown("""<div class="page-header"><div>
        <div class="page-title">Demand & Sales Analysis</div>
        <div class="page-sub">매출 실적 · 달성률 · Fast/Slow Moving SKU</div>
    </div></div>""", unsafe_allow_html=True)

    c1, c2 = st.columns(2, gap="medium")
    with c1:
        st.markdown(section_card_start("제품군별 달성률"), unsafe_allow_html=True)
        st.plotly_chart(achievement_bar(latest_f), use_container_width=True, config={"displayModeBar": False})
        st.markdown(section_card_end(), unsafe_allow_html=True)
    with c2:
        st.markdown(section_card_start("Plan vs Actual Trend"), unsafe_allow_html=True)
        st.plotly_chart(plan_vs_actual_trend(df_f), use_container_width=True, config={"displayModeBar": False})
        st.markdown(section_card_end(), unsafe_allow_html=True)

    tab1, tab2, tab3, tab4 = st.tabs(["📈 매출 성장 TOP 20", "📉 매출 부진 TOP 20", "⚡ Fast Moving", "🐢 Slow Moving"])

    with tab1:
        top20 = latest_f.sort_values("achievement_rate", ascending=False).head(20)
        st.dataframe(top20[["sku_code","product_name","plan_amt","actual_amt","achievement_rate","inv_days"]].rename(columns={
            "sku_code":"SKU","product_name":"제품명","plan_amt":"계획(억)","actual_amt":"실적(억)",
            "achievement_rate":"달성률(%)","inv_days":"재고일수",
        }), use_container_width=True, height=360)

    with tab2:
        bot20 = latest_f.sort_values("achievement_rate").head(20)
        st.dataframe(bot20[["sku_code","product_name","plan_amt","actual_amt","achievement_rate","inv_days"]].rename(columns={
            "sku_code":"SKU","product_name":"제품명","plan_amt":"계획(억)","actual_amt":"실적(억)",
            "achievement_rate":"달성률(%)","inv_days":"재고일수",
        }), use_container_width=True, height=360)

    with tab3:
        fast = latest_f[latest_f["fast_mover"] == True]
        st.info(f"⚡ Fast Moving SKU: {len(fast)}개 — 실적이 계획을 초과하고 재고일수 감소 추세")
        st.dataframe(fast[["sku_code","product_name","achievement_rate","inv_days","risk_level"]].rename(columns={
            "sku_code":"SKU","product_name":"제품명","achievement_rate":"달성률(%)","inv_days":"재고일수","risk_level":"리스크",
        }), use_container_width=True, height=340)

    with tab4:
        slow = latest_f[latest_f["slow_mover"] == True]
        st.warning(f"🐢 Slow Moving SKU: {len(slow)}개 — 판매 부진, 재고일수 증가 추세")
        st.dataframe(slow[["sku_code","product_name","achievement_rate","inv_days","end_inv_amt","risk_level"]].rename(columns={
            "sku_code":"SKU","product_name":"제품명","achievement_rate":"달성률(%)","inv_days":"재고일수",
            "end_inv_amt":"재고금액(억)","risk_level":"리스크",
        }), use_container_width=True, height=340)


# ══════════════════════════════════════════
# PAGE 5: SUPPLY & PRODUCTION
# ══════════════════════════════════════════
elif page == "🚚 Supply & Production":
    st.markdown("""<div class="page-header"><div>
        <div class="page-title">Supply & Production</div>
        <div class="page-sub">공급·생산·수입 일정 및 지연 현황</div>
    </div></div>""", unsafe_allow_html=True)

    delay_df = latest_f[latest_f["supply_delay_days"] > 0].copy()
    on_time  = latest_f[latest_f["supply_delay_days"] == 0]

    c1, c2, c3, c4 = st.columns(4, gap="small")
    c1.markdown(kpi_card_html("전체 공급 예정", f"{len(latest_f)}건", "", "blue"), unsafe_allow_html=True)
    c2.markdown(kpi_card_html("공급 지연", f"{len(delay_df)}건", "즉시 확인 필요", "danger" if len(delay_df) > 0 else ""), unsafe_allow_html=True)
    c3.markdown(kpi_card_html("정상 공급", f"{len(on_time)}건", "", "success"), unsafe_allow_html=True)
    c4.markdown(kpi_card_html("평균 지연일", f"{delay_df['supply_delay_days'].mean():.0f}일" if len(delay_df) > 0 else "0일", "", "warning"), unsafe_allow_html=True)

    st.markdown("<div style='height:16px'></div>", unsafe_allow_html=True)

    tab1, tab2 = st.tabs(["⚠️ 공급 지연 목록", "📋 전체 공급 현황"])

    with tab1:
        if delay_df.empty:
            st.success("✅ 현재 공급 지연 SKU가 없습니다.")
        else:
            show = delay_df[["sku_code","product_name","manufacturer","supply_type",
                             "supply_delay_days","supply_delay_reason","inv_days",
                             "expected_stockout_date","risk_level"]].rename(columns={
                "sku_code":"SKU","product_name":"제품명","manufacturer":"제조사",
                "supply_type":"공급유형","supply_delay_days":"지연일수",
                "supply_delay_reason":"지연사유","inv_days":"현재고일수",
                "expected_stockout_date":"예상품절일","risk_level":"리스크",
            })
            st.dataframe(show, use_container_width=True, height=400)

    with tab2:
        show2 = latest_f[["sku_code","product_name","manufacturer","supply_type",
                           "supply_qty","planned_supply_date","confirmed_supply_date",
                           "supply_delay_days","inv_days","risk_level"]].rename(columns={
            "sku_code":"SKU","product_name":"제품명","manufacturer":"제조사",
            "supply_type":"공급유형","supply_qty":"공급예정수량",
            "planned_supply_date":"계획공급일","confirmed_supply_date":"확정공급일",
            "supply_delay_days":"지연일수","inv_days":"재고일수","risk_level":"리스크",
        })
        st.dataframe(show2, use_container_width=True, height=480)


# ══════════════════════════════════════════
# PAGE 6: SKU DETAIL EXPLORER
# ══════════════════════════════════════════
elif page == "🔍 SKU Detail Explorer":
    st.markdown("""<div class="page-header"><div>
        <div class="page-title">SKU Detail Explorer</div>
        <div class="page-sub">제품별 심층 PSI 분석</div>
    </div></div>""", unsafe_allow_html=True)

    all_skus = latest_f[["sku_code","product_name"]].drop_duplicates()
    sku_options = {f"{r['sku_code']} — {r['product_name']}": r["sku_code"] for _, r in all_skus.iterrows()}
    selected_label = st.selectbox("제품 선택", list(sku_options.keys()))
    sel_code = sku_options[selected_label]

    sku_latest = latest_f[latest_f["sku_code"] == sel_code].iloc[0]
    sku_all    = df_f[df_f["sku_code"] == sel_code].sort_values("date")

    # SKU 헤더 정보
    risk = sku_latest["risk_level"]
    risk_color = RISK_COLOR_MAP.get(risk, "#6B7280")
    st.markdown(f"""
    <div class="section-card">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
            <div>
                <div style="font-size:18px;font-weight:700;color:#1A1D23">{sku_latest['product_name']}</div>
                <div style="font-size:13px;color:#6B7280;margin-top:3px">
                    {sel_code} &nbsp;·&nbsp; {sku_latest['product_group']} &nbsp;·&nbsp;
                    {sku_latest['manufacturer']} &nbsp;·&nbsp; {sku_latest['supply_type']}
                </div>
            </div>
            <div style="display:flex;gap:10px;align-items:center">
                <span style="font-size:12px;color:#6B7280">리드타임 {sku_latest['lead_time_days']}일</span>
                <span style="font-size:12px;color:#6B7280">안전재고 {sku_latest['safety_stock_days']}일</span>
                <span class="badge" style="background:{RISK_BG_MAP.get(risk,'#F3F4F6')};color:{risk_color};border:1px solid {risk_color}40;font-size:13px;padding:5px 12px">
                    {'🔴' if risk=='Critical' else '🟠' if risk=='Warning' else '🟡' if risk=='Caution' else '🟢' if risk=='Stable' else '🔵'} {risk}
                </span>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # KPI 행
    kc = st.columns(5, gap="small")
    inv_days = sku_latest["inv_days"]
    kpis2 = [
        ("월 매출", f"{sku_latest['actual_amt']:.2f}억", f"계획 {sku_latest['plan_amt']:.2f}억", ""),
        ("달성률", f"{sku_latest['achievement_rate']:.1f}%", "", "success" if sku_latest['achievement_rate'] >= 80 else "danger"),
        ("재고일수", f"{inv_days if inv_days < 999 else '999+'}일", f"안전재고 {sku_latest['safety_stock_days']}일", "danger" if inv_days < thr["warning"] else "warning" if inv_days < thr["caution"] else ""),
        ("기말재고", f"{sku_latest['end_inv_amt']:.1f}억", f"{sku_latest['end_inv_qty']:,}개", ""),
        ("예상품절일", str(sku_latest['expected_stockout_date'])[:10], "", "danger" if sku_latest['risk_level'] == 'Critical' else ""),
    ]
    for col, (lbl, val, sub, cls) in zip(kc, kpis2):
        col.markdown(kpi_card_html(lbl, val, sub, cls), unsafe_allow_html=True)

    st.markdown("<div style='height:16px'></div>", unsafe_allow_html=True)

    # 월별 트렌드
    st.markdown(section_card_start("📈 월별 PSI 트렌드"), unsafe_allow_html=True)
    if len(sku_all) > 0:
        st.plotly_chart(sku_monthly_detail(df_f, sel_code), use_container_width=True, config={"displayModeBar": False})
    else:
        st.info("데이터가 없습니다.")
    st.markdown(section_card_end(), unsafe_allow_html=True)

    # 하단 탭
    t1, t2, t3 = st.tabs(["📊 월별 상세 데이터", "🚚 공급 이력", "📝 Action Memo"])
    with t1:
        cols_to_show = ["date","plan_amt","actual_amt","supply_amt","end_inv_qty","end_inv_amt","inv_days","achievement_rate","risk_level"]
        display = sku_all[cols_to_show].copy()
        display["date"] = display["date"].dt.strftime("%Y-%m")
        st.dataframe(display.rename(columns={
            "date":"월","plan_amt":"계획(억)","actual_amt":"실적(억)","supply_amt":"공급(억)",
            "end_inv_qty":"기말재고(개)","end_inv_amt":"기말재고(억)","inv_days":"재고일수",
            "achievement_rate":"달성률(%)","risk_level":"리스크",
        }), use_container_width=True)
    with t2:
        supply_hist = sku_all[["date","supply_qty","supply_amt","planned_supply_date","confirmed_supply_date","supply_delay_days","supply_delay_reason"]].copy()
        supply_hist["date"] = supply_hist["date"].dt.strftime("%Y-%m")
        st.dataframe(supply_hist.rename(columns={
            "date":"월","supply_qty":"공급수량","supply_amt":"공급금액(억)",
            "planned_supply_date":"계획공급일","confirmed_supply_date":"확정공급일",
            "supply_delay_days":"지연일수","supply_delay_reason":"지연사유",
        }), use_container_width=True)
    with t3:
        memo = st.text_area("Action 메모", placeholder="공급 통제 현황, 마케팅 이슈, 생산 이슈, SCM 액션, 다음 팔로업 날짜 등을 입력하세요.", height=140)
        if st.button("저장"):
            st.success(f"✅ 메모 저장 완료 — {TODAY}")


# ══════════════════════════════════════════
# PAGE 7: FORECAST & AI PREDICTION
# ══════════════════════════════════════════
elif page == "🤖 Forecast & AI Prediction":
    st.markdown("""<div class="page-header"><div>
        <div class="page-title">Forecast & AI Prediction</div>
        <div class="page-sub">품절 예측 · 수요 급증 감지 · 과잉재고 경보</div>
    </div></div>""", unsafe_allow_html=True)

    # 품절 예측
    stockout_pred = latest_f.copy()
    stockout_pred["days_to_stockout"] = stockout_pred.apply(
        lambda r: max(0, (pd.to_datetime(r["expected_stockout_date"]) - pd.Timestamp.today()).days), axis=1
    )
    urgent = stockout_pred[stockout_pred["days_to_stockout"] < 30].sort_values("days_to_stockout")
    surge_skus = latest_f[latest_f["fast_mover"] == True]
    poor_skus  = latest_f[(latest_f["achievement_rate"] < 30) & (latest_f["slow_mover"] == True)]
    excess_skus_df = latest_f[latest_f["inv_days"] > thr["excess"]]

    c1, c2 = st.columns(2, gap="medium")
    with c1:
        st.markdown(section_card_start("🚨 품절 예상 — 30일 이내"), unsafe_allow_html=True)
        for _, row in urgent.head(6).iterrows():
            d = row["days_to_stockout"]
            color = DANGER if d < 14 else WARNING
            st.markdown(f"""
            <div class="insight-card {'critical' if d < 14 else 'warning'}">
                <div class="insight-title">{row['product_name']}</div>
                <div class="insight-body">D-{d}일 · 재고일수 {row['inv_days']}일 · {row['risk_level']}</div>
            </div>""", unsafe_allow_html=True)
        st.markdown(section_card_end(), unsafe_allow_html=True)

        st.markdown(section_card_start("📦 과잉재고 경보"), unsafe_allow_html=True)
        for _, row in excess_skus_df.head(5).iterrows():
            st.markdown(f"""
            <div class="insight-card info">
                <div class="insight-title">{row['product_name']}</div>
                <div class="insight-body">재고일수 {row['inv_days']}일 · 재고금액 {row['end_inv_amt']:.1f}억 · 달성률 {row['achievement_rate']:.0f}%</div>
            </div>""", unsafe_allow_html=True)
        st.markdown(section_card_end(), unsafe_allow_html=True)

    with c2:
        st.markdown(section_card_start("📈 수요 급증 감지"), unsafe_allow_html=True)
        if not surge_skus.empty:
            for _, row in surge_skus.head(6).iterrows():
                st.markdown(f"""
                <div class="insight-card warning">
                    <div class="insight-title">⚡ {row['product_name']}</div>
                    <div class="insight-body">달성률 {row['achievement_rate']:.0f}% · 재고일수 {row['inv_days']}일 · Fast Mover</div>
                </div>""", unsafe_allow_html=True)
        else:
            st.info("현재 수요 급증 감지 SKU 없음")
        st.markdown(section_card_end(), unsafe_allow_html=True)

        st.markdown(section_card_start("📉 판매 부진 SKU"), unsafe_allow_html=True)
        for _, row in poor_skus.head(5).iterrows():
            st.markdown(f"""
            <div class="insight-card critical">
                <div class="insight-title">{row['product_name']}</div>
                <div class="insight-body">달성률 {row['achievement_rate']:.0f}% · 재고일수 {row['inv_days']}일 · Slow Mover</div>
            </div>""", unsafe_allow_html=True)
        st.markdown(section_card_end(), unsafe_allow_html=True)

    # AI 예측 설명
    st.markdown("---")
    with st.expander("🔬 예측 로직 설명 (Forecast Logic)"):
        st.markdown("""
        | 지표 | 계산 공식 |
        |------|----------|
        | 품절 예상일 | 기말재고 ÷ 최근 일평균 출하량 |
        | 수요 급증 | 최근 4주 출하 > 13주 평균 × 1.2 AND 달성률 > 100% |
        | 과잉재고 | 재고일수 > 120일 AND 달성률 < 50% |
        | 공급 갭 | 필요 공급량 - 확정 공급량 |
        | 리스크 등급 | Critical: <20일 / Warning: 20~30일 / Caution: 30~60일 / Stable: >60일 / Excess: >120일 |
        """)


# ══════════════════════════════════════════
# PAGE 8: ACTION TRACKER
# ══════════════════════════════════════════
elif page == "✅ Action Tracker":
    st.markdown("""<div class="page-header"><div>
        <div class="page-title">Action Tracker</div>
        <div class="page-sub">이슈별 액션 현황 및 담당자 추적</div>
    </div></div>""", unsafe_allow_html=True)

    acts = st.session_state.actions.copy()

    # 필터
    fc1, fc2, fc3 = st.columns(3, gap="small")
    with fc1:
        f_status = st.multiselect("상태", acts["status"].unique(), default=list(acts["status"].unique()))
    with fc2:
        f_dept   = st.multiselect("부서", acts["department"].unique(), default=list(acts["department"].unique()))
    with fc3:
        f_risk_a = st.multiselect("리스크", acts["risk_level"].unique(), default=list(acts["risk_level"].unique()))

    acts_f = acts[
        acts["status"].isin(f_status) &
        acts["department"].isin(f_dept) &
        acts["risk_level"].isin(f_risk_a)
    ]

    # 상태별 카운트
    status_counts = acts_f["status"].value_counts()
    sc = st.columns(5, gap="small")
    for col, status in zip(sc, ["Not Started","In Progress","Waiting","Completed","Delayed"]):
        cnt = status_counts.get(status, 0)
        col.markdown(kpi_card_html(status, str(cnt), "", "danger" if status=="Delayed" else "success" if status=="Completed" else ""), unsafe_allow_html=True)

    st.markdown("<div style='height:16px'></div>", unsafe_allow_html=True)
    st.dataframe(
        acts_f,
        use_container_width=True,
        height=440,
        column_config={
            "status": st.column_config.SelectboxColumn("상태", options=["Not Started","In Progress","Waiting","Completed","Delayed"]),
            "risk_level": st.column_config.TextColumn("리스크"),
            "due_date": st.column_config.DateColumn("마감일"),
        },
    )

    # 신규 이슈 추가
    with st.expander("➕ 신규 이슈 추가"):
        nc1, nc2, nc3 = st.columns(3)
        new_sku = nc1.text_input("SKU 코드")
        new_issue = nc2.selectbox("이슈 유형", ["품절위험","공급지연","과잉재고","수요급증","판매부진","생산이슈","수입·통관이슈","품질이슈"])
        new_owner = nc3.text_input("담당자")
        new_action = st.text_area("액션 내용", height=80)
        if st.button("이슈 추가"):
            new_row = {
                "issue_id": f"ISS-{datetime.today().strftime('%Y%m%d%H%M%S')}",
                "sku_code": new_sku, "product_name": "",
                "issue_type": new_issue, "risk_level": "Warning",
                "action_item": new_action, "owner": new_owner,
                "department": "SCM팀", "due_date": (datetime.today() + timedelta(days=7)).strftime("%Y-%m-%d"),
                "status": "Not Started", "latest_update": TODAY, "next_action": "",
            }
            st.session_state.actions = pd.concat([st.session_state.actions, pd.DataFrame([new_row])], ignore_index=True)
            st.success("✅ 이슈 추가 완료")
            st.rerun()


# ══════════════════════════════════════════
# PAGE 9: MASTER DATA / SETTINGS
# ══════════════════════════════════════════
elif page == "⚙️ Master Data / Settings":
    st.markdown("""<div class="page-header"><div>
        <div class="page-title">Master Data / Settings</div>
        <div class="page-sub">기준 데이터 관리 및 임계값 설정</div>
    </div></div>""", unsafe_allow_html=True)

    tab1, tab2 = st.tabs(["📋 SKU 마스터", "⚙️ 임계값 설정"])

    with tab1:
        master_cols = ["sku_code","product_name","product_group","business_unit","manufacturer","supply_type","lead_time_days","safety_stock_days"]
        master = latest_f[master_cols].drop_duplicates().rename(columns={
            "sku_code":"SKU","product_name":"제품명","product_group":"제품군",
            "business_unit":"사업부","manufacturer":"제조사","supply_type":"공급유형",
            "lead_time_days":"리드타임(일)","safety_stock_days":"안전재고(일)",
        })
        st.dataframe(master, use_container_width=True, height=400)
        buf = io.BytesIO()
        master.to_excel(buf, index=False)
        st.download_button("📥 마스터 다운로드", buf.getvalue(), f"sku_master_{TODAY}.xlsx")

    with tab2:
        st.markdown("**재고일수 임계값 (일 기준)**")
        tc = st.columns(5, gap="small")
        labels = ["Critical (위험)", "Warning (경고)", "Caution (주의)", "Stable (정상)", "Excess (과잉)"]
        keys   = ["critical", "warning", "caution", "stable", "excess"]
        defaults = [20, 30, 60, 60, 120]
        for col, lbl, key, default in zip(tc, labels, keys, defaults):
            with col:
                st.session_state.thresholds[key] = st.number_input(
                    lbl, min_value=1, max_value=365,
                    value=st.session_state.thresholds.get(key, default), step=5
                )

        st.markdown("---")
        st.markdown("**데이터 컬럼 매핑 가이드**")
        st.markdown("""
        실제 Excel 파일을 업로드할 때 아래 컬럼명을 맞춰주세요:

        | 필수 컬럼 | 설명 |
        |-----------|------|
        | `date` | 기준 월 (YYYY-MM 형식) |
        | `sku_code` | SKU 코드 |
        | `product_name` | 제품명 |
        | `product_group` | 제품군 |
        | `business_unit` | 사업부 |
        | `manufacturer` | 제조사 |
        | `supply_type` | 공급유형 |
        | `plan_amt` | 사업계획금액(억) |
        | `actual_amt` | 실제매출금액(억) |
        | `end_inv_qty` | 기말재고수량(개) |
        | `end_inv_amt` | 기말재고금액(억) |
        | `inv_days` | 재고일수 |
        | `supply_delay_days` | 공급지연일수 |
        | `expected_stockout_date` | 예상품절일 |
        | `risk_level` | 리스크등급 |
        """)
