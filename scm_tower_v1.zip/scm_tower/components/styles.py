"""
SCM Supply Control Tower — UI Styles & Components
"""

PREMIUM_CSS = """
<style>
/* ── Google Fonts ── */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

/* ── 전역 리셋 ── */
html, body, [class*="css"] {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif !important;
    background-color: #F8F9FB !important;
    color: #1A1D23 !important;
}

/* ── 사이드바 ── */
[data-testid="stSidebar"] {
    background: #FFFFFF !important;
    border-right: 1px solid #EAECF0 !important;
    box-shadow: 2px 0 8px rgba(0,0,0,0.04) !important;
}
[data-testid="stSidebar"] .block-container { padding: 1.2rem 1rem !important; }

/* ── 사이드바 제목 ── */
.sidebar-logo {
    display: flex; align-items: center; gap: 10px;
    padding: 8px 4px 20px; border-bottom: 1px solid #EAECF0; margin-bottom: 16px;
}
.sidebar-logo-mark {
    width: 32px; height: 32px; border-radius: 8px;
    background: linear-gradient(135deg, #0052CC, #0066FF);
    display: flex; align-items: center; justify-content: center;
    font-size: 16px; flex-shrink: 0;
}
.sidebar-logo-text { font-size: 13px; font-weight: 600; color: #1A1D23; line-height: 1.3; }
.sidebar-logo-sub  { font-size: 11px; color: #6B7280; }

/* ── 메인 컨테이너 ── */
.main .block-container {
    padding: 1.5rem 2rem 2rem !important;
    max-width: 1400px !important;
}

/* ── 페이지 헤더 ── */
.page-header {
    display: flex; align-items: flex-end; justify-content: space-between;
    padding-bottom: 16px; border-bottom: 1px solid #EAECF0; margin-bottom: 24px;
}
.page-title { font-size: 22px; font-weight: 700; color: #1A1D23; letter-spacing: -0.3px; }
.page-sub   { font-size: 13px; color: #6B7280; margin-top: 3px; }
.page-date  { font-size: 12px; color: #9CA3AF; }

/* ── KPI 카드 ── */
.kpi-card {
    background: #FFFFFF; border: 1px solid #EAECF0;
    border-radius: 12px; padding: 18px 20px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.04), 0 1px 2px rgba(0,0,0,0.02);
    transition: box-shadow .15s;
}
.kpi-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
.kpi-label { font-size: 11px; color: #6B7280; text-transform: uppercase; letter-spacing: .06em; margin-bottom: 8px; }
.kpi-value { font-size: 26px; font-weight: 700; color: #1A1D23; line-height: 1; }
.kpi-sub   { font-size: 12px; color: #9CA3AF; margin-top: 6px; }
.kpi-value.danger  { color: #DC2626; }
.kpi-value.warning { color: #D97706; }
.kpi-value.success { color: #059669; }
.kpi-value.blue    { color: #0052CC; }

/* ── 리스크 배지 ── */
.badge {
    display: inline-flex; align-items: center; gap: 4px;
    font-size: 11px; font-weight: 600; padding: 3px 9px;
    border-radius: 20px; white-space: nowrap; letter-spacing: .02em;
}
.badge-critical { background: #FEF2F2; color: #DC2626; border: 1px solid #FECACA; }
.badge-warning  { background: #FFFBEB; color: #D97706; border: 1px solid #FDE68A; }
.badge-caution  { background: #FFF7ED; color: #EA580C; border: 1px solid #FDBA74; }
.badge-stable   { background: #F0FDF4; color: #059669; border: 1px solid #A7F3D0; }
.badge-excess   { background: #EFF6FF; color: #0052CC; border: 1px solid #BFDBFE; }

/* ── 섹션 카드 ── */
.section-card {
    background: #FFFFFF; border: 1px solid #EAECF0;
    border-radius: 12px; padding: 20px 22px; margin-bottom: 16px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.04);
}
.section-title {
    font-size: 13px; font-weight: 600; color: #374151;
    text-transform: uppercase; letter-spacing: .05em; margin-bottom: 16px;
    padding-bottom: 10px; border-bottom: 1px solid #F3F4F6;
}

/* ── 인사이트 카드 ── */
.insight-card {
    background: #FFFFFF; border: 1px solid #EAECF0;
    border-radius: 10px; padding: 14px 16px; margin-bottom: 8px;
    border-left: 3px solid;
}
.insight-card.critical { border-left-color: #DC2626; background: #FFF8F8; }
.insight-card.warning  { border-left-color: #D97706; background: #FFFCF5; }
.insight-card.success  { border-left-color: #059669; background: #F8FFF9; }
.insight-card.info     { border-left-color: #0052CC; background: #F5F8FF; }
.insight-title { font-size: 12px; font-weight: 600; margin-bottom: 4px; }
.insight-card.critical .insight-title { color: #DC2626; }
.insight-card.warning  .insight-title { color: #D97706; }
.insight-card.success  .insight-title { color: #059669; }
.insight-card.info     .insight-title { color: #0052CC; }
.insight-body { font-size: 12px; color: #4B5563; line-height: 1.55; }

/* ── Streamlit 기본 요소 오버라이드 ── */
.stButton > button {
    background: #0052CC !important; color: #fff !important;
    border: none !important; border-radius: 8px !important;
    font-size: 13px !important; font-weight: 500 !important;
    padding: 8px 18px !important; transition: opacity .15s !important;
}
.stButton > button:hover { opacity: .85 !important; }

/* 다운로드 버튼 */
.stDownloadButton > button {
    background: #F3F4F6 !important; color: #374151 !important;
    border: 1px solid #D1D5DB !important; border-radius: 8px !important;
    font-size: 12px !important;
}

/* 셀렉트박스, 텍스트인풋 */
.stSelectbox > div > div,
.stMultiSelect > div > div,
.stTextInput > div > div > input {
    border-radius: 8px !important;
    border: 1px solid #D1D5DB !important;
    font-size: 13px !important;
}

/* 슬라이더 */
.stSlider > div > div > div { background: #0052CC !important; }

/* 탭 */
.stTabs [data-baseweb="tab-list"] {
    background: #F3F4F6 !important;
    border-radius: 10px !important;
    padding: 3px !important;
    gap: 3px !important;
}
.stTabs [data-baseweb="tab"] {
    border-radius: 8px !important;
    font-size: 13px !important;
    font-weight: 500 !important;
    color: #6B7280 !important;
    padding: 8px 16px !important;
}
.stTabs [aria-selected="true"] {
    background: #FFFFFF !important;
    color: #1A1D23 !important;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1) !important;
}

/* 데이터프레임 */
.dataframe { border-radius: 8px !important; font-size: 12px !important; }
thead tr th { background: #F9FAFB !important; font-weight: 600 !important; color: #374151 !important; }

/* 메트릭 */
[data-testid="metric-container"] {
    background: #FFFFFF !important; border: 1px solid #EAECF0 !important;
    border-radius: 12px !important; padding: 14px 18px !important;
}

/* 구분선 */
hr { border-color: #EAECF0 !important; margin: 1rem 0 !important; }

/* 알림 박스 숨기기 */
[data-testid="stNotification"] { border-radius: 10px !important; }

/* 스크롤바 */
::-webkit-scrollbar { width: 5px; height: 5px; }
::-webkit-scrollbar-track { background: #F3F4F6; }
::-webkit-scrollbar-thumb { background: #D1D5DB; border-radius: 3px; }
</style>
"""

RISK_COLOR_MAP = {
    "Critical": "#DC2626",
    "Warning":  "#D97706",
    "Caution":  "#EA580C",
    "Stable":   "#059669",
    "Excess":   "#0052CC",
}

RISK_BG_MAP = {
    "Critical": "#FEF2F2",
    "Warning":  "#FFFBEB",
    "Caution":  "#FFF7ED",
    "Stable":   "#F0FDF4",
    "Excess":   "#EFF6FF",
}

STATUS_COLOR_MAP = {
    "Not Started": "#6B7280",
    "In Progress": "#0052CC",
    "Waiting":     "#D97706",
    "Completed":   "#059669",
    "Delayed":     "#DC2626",
}


def risk_badge_html(risk: str) -> str:
    color = RISK_COLOR_MAP.get(risk, "#6B7280")
    bg    = RISK_BG_MAP.get(risk, "#F3F4F6")
    dot_map = {"Critical":"🔴","Warning":"🟠","Caution":"🟡","Stable":"🟢","Excess":"🔵"}
    dot = dot_map.get(risk, "⚪")
    return f'<span class="badge" style="background:{bg};color:{color};border:1px solid {color}40">{dot} {risk}</span>'


def kpi_card_html(label: str, value: str, sub: str = "", color_class: str = "") -> str:
    return f"""
    <div class="kpi-card">
        <div class="kpi-label">{label}</div>
        <div class="kpi-value {color_class}">{value}</div>
        {f'<div class="kpi-sub">{sub}</div>' if sub else ''}
    </div>
    """


def insight_card_html(title: str, body: str, level: str = "info") -> str:
    return f"""
    <div class="insight-card {level}">
        <div class="insight-title">{title}</div>
        <div class="insight-body">{body}</div>
    </div>
    """


def section_card_start(title: str) -> str:
    return f"""<div class="section-card"><div class="section-title">{title}</div>"""


def section_card_end() -> str:
    return """</div>"""
