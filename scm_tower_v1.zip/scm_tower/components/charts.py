"""
SCM Supply Control Tower — Plotly Chart Components
모든 차트는 이 파일에서 관리합니다.
"""

import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np
from components.styles import RISK_COLOR_MAP

# ── 공통 레이아웃 설정 ──────────────────────────────────────────
LAYOUT_BASE = dict(
    font=dict(family="Inter, sans-serif", size=12, color="#374151"),
    paper_bgcolor="white",
    plot_bgcolor="white",
    margin=dict(l=16, r=16, t=32, b=16),
    legend=dict(
        orientation="h", yanchor="bottom", y=1.02,
        xanchor="right", x=1, font=dict(size=11)
    ),
    hoverlabel=dict(
        bgcolor="white", bordercolor="#E5E7EB",
        font=dict(size=12, family="Inter, sans-serif")
    ),
)

AXIS_STYLE = dict(
    showgrid=True, gridcolor="#F3F4F6", gridwidth=1,
    showline=True, linecolor="#E5E7EB", linewidth=1,
    tickfont=dict(size=11, color="#6B7280"),
    zeroline=False,
)

PRIMARY   = "#0052CC"
SECONDARY = "#00A3BF"
DANGER    = "#DC2626"
WARNING   = "#D97706"
SUCCESS   = "#059669"
NEUTRAL   = "#9CA3AF"


def plan_vs_actual_trend(df: pd.DataFrame, sku_code: str = None) -> go.Figure:
    """월별 계획 vs 실적 vs 재고 트렌드 라인 차트"""
    if sku_code:
        d = df[df["sku_code"] == sku_code].copy()
    else:
        d = df.groupby("date", as_index=False).agg(
            plan_amt=("plan_amt","sum"),
            actual_amt=("actual_amt","sum"),
            supply_amt=("supply_amt","sum"),
            end_inv_amt=("end_inv_amt","sum"),
        )
    d = d.sort_values("date")
    months = d["date"].dt.strftime("%y.%m")

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=months, y=d["plan_amt"], name="사업계획",
        line=dict(color=NEUTRAL, width=1.5, dash="dot"),
        mode="lines+markers", marker=dict(size=5),
    ))
    fig.add_trace(go.Scatter(
        x=months, y=d["actual_amt"], name="실제 매출",
        line=dict(color=PRIMARY, width=2.5),
        mode="lines+markers", marker=dict(size=6),
        fill="tonexty", fillcolor="rgba(0,82,204,0.05)",
    ))
    fig.add_trace(go.Bar(
        x=months, y=d["supply_amt"], name="공급 입고",
        marker_color="rgba(0,163,191,0.35)",
        yaxis="y",
    ))
    fig.add_trace(go.Scatter(
        x=months, y=d["end_inv_amt"], name="기말재고",
        line=dict(color=SUCCESS, width=2, dash="dash"),
        mode="lines+markers", marker=dict(size=5),
    ))

    fig.update_layout(
        **LAYOUT_BASE,
        barmode="overlay",
        yaxis=dict(**AXIS_STYLE, title="금액 (억원)", tickformat=".1f"),
        xaxis=dict(**AXIS_STYLE),
        height=280,
    )
    return fig


def risk_heatmap(df: pd.DataFrame) -> go.Figure:
    """제품군 × 리스크 등급 히트맵"""
    risk_order = ["Critical", "Warning", "Caution", "Stable", "Excess"]
    pivot = df.groupby(["product_group", "risk_level"]).size().unstack(fill_value=0)
    pivot = pivot.reindex(columns=[r for r in risk_order if r in pivot.columns])

    color_scale = [
        [0.0,  "#F0FDF4"],
        [0.25, "#FFF7ED"],
        [0.5,  "#FFFBEB"],
        [0.75, "#FEF2F2"],
        [1.0,  "#7F1D1D"],
    ]

    fig = go.Figure(go.Heatmap(
        z=pivot.values,
        x=pivot.columns.tolist(),
        y=pivot.index.tolist(),
        colorscale=color_scale,
        text=pivot.values,
        texttemplate="%{text}",
        textfont=dict(size=13, color="#374151"),
        showscale=False,
        hovertemplate="%{y} × %{x}: %{z}개<extra></extra>",
    ))
    fig.update_layout(
        **LAYOUT_BASE,
        height=260,
        xaxis=dict(side="top", tickfont=dict(size=12, color="#374151")),
        yaxis=dict(tickfont=dict(size=12, color="#374151")),
        margin=dict(l=120, r=16, t=48, b=16),
    )
    return fig


def inventory_scatter(df: pd.DataFrame) -> go.Figure:
    """재고일수 vs 매출금액 산점도"""
    latest = df[df["date"] == df["date"].max()].copy()
    color_map = {
        "Critical": DANGER, "Warning": WARNING,
        "Caution": "#EA580C", "Stable": SUCCESS, "Excess": PRIMARY,
    }

    fig = go.Figure()
    for risk, grp in latest.groupby("risk_level"):
        fig.add_trace(go.Scatter(
            x=grp["inv_days"].clip(upper=400),
            y=grp["actual_amt"],
            mode="markers",
            name=risk,
            marker=dict(
                size=np.sqrt(grp["end_inv_amt"].clip(lower=0.1)) * 8,
                color=color_map.get(risk, NEUTRAL),
                opacity=0.7,
                line=dict(color="white", width=1.5),
            ),
            text=grp["product_name"],
            hovertemplate="<b>%{text}</b><br>재고일수: %{x}일<br>매출: %{y:.1f}억<extra></extra>",
        ))

    # 사분면 배경
    fig.add_vline(x=60,  line_width=1, line_dash="dot", line_color="#E5E7EB")
    fig.add_hline(y=latest["actual_amt"].median(), line_width=1, line_dash="dot", line_color="#E5E7EB")

    fig.update_layout(
        **LAYOUT_BASE,
        height=360,
        xaxis=dict(**AXIS_STYLE, title="재고일수", range=[0, 420]),
        yaxis=dict(**AXIS_STYLE, title="실제 매출 (억원)"),
    )
    return fig


def supply_waterfall(df: pd.DataFrame, sku_code: str) -> go.Figure:
    """공급 갭 워터폴"""
    d = df[df["sku_code"] == sku_code].sort_values("date").tail(3)
    months = d["date"].dt.strftime("%y.%m").tolist()

    fig = go.Figure()
    fig.add_trace(go.Waterfall(
        x=months,
        measure=["relative"] * len(months),
        y=(d["supply_qty"] - d["actual_qty"]).tolist(),
        connector=dict(line=dict(color="#E5E7EB")),
        increasing=dict(marker_color=SUCCESS),
        decreasing=dict(marker_color=DANGER),
        text=(d["supply_qty"] - d["actual_qty"]).map(lambda v: f"+{v:,.0f}" if v >= 0 else f"{v:,.0f}").tolist(),
        textposition="outside",
    ))
    fig.update_layout(
        **LAYOUT_BASE,
        height=240,
        yaxis=dict(**AXIS_STYLE, title="공급-판매 갭 (개)"),
        xaxis=dict(**AXIS_STYLE),
        showlegend=False,
    )
    return fig


def achievement_bar(df: pd.DataFrame) -> go.Figure:
    """제품군별 달성률 수평 막대"""
    grp = df.groupby("product_group").agg(
        plan_amt=("plan_amt","sum"),
        actual_amt=("actual_amt","sum"),
    ).reset_index()
    grp["rate"] = (grp["actual_amt"] / grp["plan_amt"] * 100).round(1)
    grp = grp.sort_values("rate", ascending=True)
    colors = [DANGER if r < 50 else WARNING if r < 80 else SUCCESS for r in grp["rate"]]

    fig = go.Figure(go.Bar(
        x=grp["rate"], y=grp["product_group"],
        orientation="h",
        marker_color=colors,
        text=grp["rate"].map(lambda v: f"{v:.0f}%"),
        textposition="outside",
        cliponaxis=False,
    ))
    fig.add_vline(x=100, line_width=1.5, line_dash="dot", line_color=NEUTRAL)
    fig.update_layout(
        **LAYOUT_BASE,
        height=240,
        xaxis=dict(**AXIS_STYLE, title="달성률 (%)", range=[0, 140]),
        yaxis=dict(**AXIS_STYLE),
        showlegend=False,
        margin=dict(l=100, r=60, t=24, b=16),
    )
    return fig


def inv_days_gauge(inv_days: int, thresholds: dict) -> go.Figure:
    """단일 SKU 재고일수 게이지"""
    max_val = 200
    val = min(inv_days, max_val)
    color = (
        DANGER  if inv_days < thresholds["critical"] else
        WARNING if inv_days < thresholds["warning"]  else
        "#EA580C" if inv_days < thresholds["caution"] else
        PRIMARY if inv_days > thresholds["excess"]   else
        SUCCESS
    )

    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=val,
        number=dict(suffix="일", font=dict(size=24, color=color)),
        gauge=dict(
            axis=dict(range=[0, max_val], tickwidth=1, tickcolor="#E5E7EB", tickfont=dict(size=10)),
            bar=dict(color=color, thickness=0.25),
            bgcolor="#F9FAFB",
            borderwidth=0,
            steps=[
                dict(range=[0, thresholds["critical"]], color="#FEF2F2"),
                dict(range=[thresholds["critical"], thresholds["warning"]], color="#FFFBEB"),
                dict(range=[thresholds["warning"], thresholds["caution"]], color="#FFF7ED"),
                dict(range=[thresholds["caution"], thresholds["excess"]], color="#F0FDF4"),
                dict(range=[thresholds["excess"], max_val], color="#EFF6FF"),
            ],
        ),
    ))
    fig.update_layout(
        paper_bgcolor="white", plot_bgcolor="white",
        height=180, margin=dict(l=20, r=20, t=20, b=10),
        font=dict(family="Inter, sans-serif"),
    )
    return fig


def stockout_timeline(df: pd.DataFrame) -> go.Figure:
    """품절 예상 TOP 품목 수평 타임라인"""
    today = pd.Timestamp.today()
    at_risk = df[df["date"] == df["date"].max()].copy()
    at_risk = at_risk[at_risk["risk_level"].isin(["Critical", "Warning"])].head(10)
    at_risk["expected_stockout_date"] = pd.to_datetime(at_risk["expected_stockout_date"])
    at_risk["days_left"] = (at_risk["expected_stockout_date"] - today).dt.days.clip(lower=0)
    at_risk = at_risk.sort_values("days_left").head(10)

    colors = [DANGER if d < 14 else WARNING if d < 30 else SUCCESS for d in at_risk["days_left"]]
    short_name = at_risk["product_name"].str[:18]

    fig = go.Figure(go.Bar(
        x=at_risk["days_left"],
        y=short_name,
        orientation="h",
        marker_color=colors,
        text=at_risk["days_left"].map(lambda v: f"D-{v}일"),
        textposition="outside",
        cliponaxis=False,
    ))
    fig.add_vline(x=14, line_width=1.5, line_dash="dot", line_color=DANGER, annotation_text="14일", annotation_position="top")
    fig.add_vline(x=30, line_width=1.5, line_dash="dot", line_color=WARNING, annotation_text="30일", annotation_position="top")

    fig.update_layout(
        **LAYOUT_BASE,
        height=320,
        xaxis=dict(**AXIS_STYLE, title="품절까지 잔여일수", range=[0, 60]),
        yaxis=dict(**AXIS_STYLE),
        showlegend=False,
        margin=dict(l=160, r=60, t=32, b=16),
    )
    return fig


def inv_group_bar(df: pd.DataFrame) -> go.Figure:
    """제품군별 재고금액 막대"""
    grp = df.groupby("product_group")["end_inv_amt"].sum().reset_index()
    grp = grp.sort_values("end_inv_amt", ascending=False)

    fig = go.Figure(go.Bar(
        x=grp["product_group"],
        y=grp["end_inv_amt"],
        marker_color=PRIMARY,
        marker_opacity=0.85,
        text=grp["end_inv_amt"].map(lambda v: f"{v:.0f}억"),
        textposition="outside",
    ))
    fig.update_layout(
        **LAYOUT_BASE,
        height=260,
        yaxis=dict(**AXIS_STYLE, title="재고금액 (억원)"),
        xaxis=dict(**AXIS_STYLE),
        showlegend=False,
    )
    return fig


def sku_monthly_detail(df: pd.DataFrame, sku_code: str) -> go.Figure:
    """SKU 상세 — 월별 멀티 트렌드"""
    d = df[df["sku_code"] == sku_code].sort_values("date")
    months = d["date"].dt.strftime("%y.%m")

    fig = go.Figure()
    traces = [
        ("plan_amt",    "사업계획", NEUTRAL,   "dot",   "lines", False),
        ("actual_amt",  "실제매출", PRIMARY,   "solid", "lines+markers", False),
        ("supply_amt",  "공급입고", SECONDARY, "solid", "bar",   True),
        ("end_inv_amt", "기말재고", SUCCESS,   "dash",  "lines+markers", False),
    ]
    for col, name, color, dash, mode, is_bar in traces:
        if is_bar:
            fig.add_trace(go.Bar(
                x=months, y=d[col], name=name,
                marker_color=color, opacity=0.4, yaxis="y",
            ))
        else:
            fig.add_trace(go.Scatter(
                x=months, y=d[col], name=name,
                line=dict(color=color, width=2, dash=dash),
                mode=mode, marker=dict(size=5),
            ))

    fig.update_layout(
        **LAYOUT_BASE,
        barmode="overlay",
        height=300,
        yaxis=dict(**AXIS_STYLE, title="금액 (억원)"),
        xaxis=dict(**AXIS_STYLE),
    )
    return fig
