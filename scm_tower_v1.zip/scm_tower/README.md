# 🏗️ SCM Supply Control Tower

**Premium Pharmaceutical SCM Executive Dashboard**  
Streamlit + Plotly + Pandas 기반 공급망 관제탑

---

## 📁 폴더 구조

```
scm_tower/
├── app.py                    ← 메인 Streamlit 앱 (진입점)
├── requirements.txt          ← 패키지 의존성
├── .streamlit/
│   └── config.toml          ← 테마 설정
├── data/
│   ├── __init__.py
│   └── sample_data.py       ← 샘플 데이터 생성 / 실데이터 로더
├── components/
│   ├── __init__.py
│   ├── styles.py            ← CSS, KPI 카드, 배지 컴포넌트
│   └── charts.py            ← Plotly 차트 함수
└── README.md
```

---

## 🚀 로컬 실행

### 1. 환경 설정
```bash
# Python 3.9 이상 필요
python -m venv venv
source venv/bin/activate        # Mac/Linux
venv\Scripts\activate           # Windows

pip install -r requirements.txt
```

### 2. 앱 실행
```bash
cd scm_tower
streamlit run app.py
```

브라우저에서 `http://localhost:8501` 접속

---

## 📊 메뉴 구성

| 메뉴 | 대상 | 주요 기능 |
|------|------|----------|
| 📊 Executive Overview | 경영진 | 전체 Supply 리스크 3초 파악, KPI, 히트맵 |
| ⚠️ Supply Risk Monitoring | SCM 매니저 | SKU별 리스크 테이블, 필터, 다운로드 |
| 📦 Inventory Analytics | SCM 매니저 | 과잉/부족 재고 분석, 산점도 |
| 📈 Demand & Sales Analysis | 마케팅·SCM | 달성률, Fast/Slow Moving SKU |
| 🚚 Supply & Production | 구매·생산팀 | 공급 지연 현황, 일정 관리 |
| 🔍 SKU Detail Explorer | 실무 담당자 | SKU별 PSI 드릴다운, 메모 |
| 🤖 Forecast & AI Prediction | SCM 매니저 | 품절 예측, 수요급증 감지 |
| ✅ Action Tracker | 전체 | 이슈별 액션 추적, 담당자 관리 |
| ⚙️ Master Data / Settings | 관리자 | 마스터 데이터, 임계값 설정 |

---

## 📅 데이터 업데이트 방법

### 방법 A — 사이드바 Excel 업로드 (권장)
1. 사이드바 하단 **"데이터 업로드"** 버튼 클릭
2. 아래 컬럼이 포함된 Excel/CSV 파일 선택
3. 자동으로 모든 페이지에 반영

### 방법 B — 코드 교체
`data/sample_data.py`의 `generate_monthly_data()` 함수를 아래처럼 교체:
```python
def generate_monthly_data(months_back=6):
    df = pd.read_excel("data/your_monthly_data.xlsx")
    df["date"] = pd.to_datetime(df["date"])
    return df
```

### 필수 Excel 컬럼
| 컬럼 | 형식 | 예시 |
|------|------|------|
| date | YYYY-MM | 2026-05 |
| sku_code | 문자열 | 9000072 |
| product_name | 문자열 | 올메텍플러스 30T |
| product_group | 문자열 | 순환기 |
| business_unit | 문자열 | ETC사업부 |
| manufacturer | 문자열 | 대웅제약(자체) |
| supply_type | 문자열 | 자체생산 |
| plan_amt | 숫자(억) | 3.20 |
| actual_amt | 숫자(억) | 2.85 |
| end_inv_qty | 정수(개) | 150000 |
| end_inv_amt | 숫자(억) | 20.4 |
| inv_days | 정수(일) | 45 |
| supply_delay_days | 정수(일) | 0 |
| expected_stockout_date | YYYY-MM-DD | 2026-08-15 |
| risk_level | Critical/Warning/Caution/Stable/Excess | Warning |
| achievement_rate | 숫자(%) | 89.0 |

---

## ☁️ Streamlit Cloud 배포

### 1. GitHub 저장소 생성
```bash
git init
git add .
git commit -m "Initial commit: SCM Supply Control Tower"
git remote add origin https://github.com/[계정명]/scm-tower.git
git push -u origin main
```

### 2. Streamlit Cloud 배포
1. [share.streamlit.io](https://share.streamlit.io) 접속
2. **"New app"** 클릭
3. GitHub 저장소 선택
4. Main file path: `app.py`
5. **"Deploy"** 클릭

### 3. 배포 URL 확인
```
https://[계정명]-scm-tower-app-[hash].streamlit.app
```

---

## 🎨 디자인 원칙

- **White-first**: 흰 배경, 소프트 그림자, 얇은 구분선
- **색상 체계**: Blue(#0052CC) 기본 · Red(#DC2626) 위험 · Orange(#D97706) 경고 · Green(#059669) 정상
- **타이포**: Inter 폰트 · 계층적 크기 체계
- **Apple + Stripe + Linear 스타일**: 깔끔한 카드, 부드러운 전환
- **McKinsey 리포팅**: 경영진이 3초 안에 리스크 파악 가능

---

## 📌 리스크 등급 기준 (기본값, 변경 가능)

| 등급 | 재고일수 | 조치 |
|------|---------|------|
| 🔴 Critical | 0~20일 | 즉시 긴급 입고 조율 |
| 🟠 Warning | 20~30일 | 당일 모니터링·공급 확인 |
| 🟡 Caution | 30~60일 | 주간 모니터링 |
| 🟢 Stable | 60~120일 | 정상 |
| 🔵 Excess | 120일 초과 | 공급 조정·판매 촉진 |

---

*SCM Supply Control Tower v1.0 — Built with Streamlit & Plotly*
