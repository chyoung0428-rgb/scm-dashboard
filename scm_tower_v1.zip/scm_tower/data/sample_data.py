"""
SCM Supply Control Tower — Sample Data Generator
실제 운영 시 이 파일의 generate_*() 함수를 Excel/CSV 로더로 교체하세요.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random

random.seed(42)
np.random.seed(42)

# ── 기준 마스터 데이터 ──────────────────────────────────────────
PRODUCT_GROUPS = ["순환기", "당뇨·내분비", "소화기", "신경·근골격", "OTC·일반", "글로벌"]
BUSINESS_UNITS = ["ETC사업부", "CH사업부", "글로벌사업부"]
MANUFACTURERS   = ["대웅제약(자체)", "종근당", "한미약품", "글로벌CMO-A", "글로벌CMO-B", "위탁생산-국내"]
SUPPLY_TYPES    = ["자체생산", "CMO위탁", "수입", "국내구매"]
CHANNELS        = ["간납도매", "종합도매", "더샵직거래", "병원직납", "수출"]

SKUS = [
    # (코드, 제품명, 그룹, 사업부, 제조사, 공급유형, 리드타임, 안전재고일)
    ("9000072", "올메텍플러스정 20/12.5mg 30T",    "순환기",      "ETC사업부",  "대웅제약(자체)", "자체생산", 21, 30),
    ("9000073", "올메텍플러스정 20/12.5mg 300T",   "순환기",      "ETC사업부",  "대웅제약(자체)", "자체생산", 21, 30),
    ("9000065", "올메텍정 20mg 30T",               "순환기",      "ETC사업부",  "대웅제약(자체)", "자체생산", 21, 30),
    ("9000133", "올메텍정 10mg 30T",               "순환기",      "ETC사업부",  "대웅제약(자체)", "자체생산", 21, 30),
    ("7000807", "릭시아나정 30mg 28T",             "순환기",      "ETC사업부",  "글로벌CMO-A",  "수입",     45, 45),
    ("7000808", "릭시아나정 60mg 28T",             "순환기",      "ETC사업부",  "글로벌CMO-A",  "수입",     45, 45),
    ("9303062", "펙수클루정 40mg 28T",             "소화기",      "ETC사업부",  "대웅제약(자체)", "자체생산", 21, 30),
    ("9311337", "펙수클루정 20mg 28T",             "소화기",      "ETC사업부",  "대웅제약(자체)", "자체생산", 21, 30),
    ("9304303", "펙수클루정 10mg 300T",            "소화기",      "ETC사업부",  "대웅제약(자체)", "자체생산", 21, 30),
    ("9000080", "다이아벡스정 1000mg 100T",        "당뇨·내분비", "ETC사업부",  "대웅제약(자체)", "자체생산", 28, 30),
    ("9000099", "다이아벡스정 1000mg 30T",         "당뇨·내분비", "ETC사업부",  "대웅제약(자체)", "자체생산", 28, 30),
    ("9304997", "엔블로정 0.3mg 30T",              "당뇨·내분비", "ETC사업부",  "글로벌CMO-B",  "수입",     60, 60),
    ("7002500", "디페리손서방정 75mg 30T",          "신경·근골격", "ETC사업부",  "종근당",        "국내구매", 14, 21),
    ("7300719", "브리덱스주 2ml",                  "신경·근골격", "ETC사업부",  "대웅제약(자체)", "자체생산", 30, 30),
    ("9000290", "대웅프리미돈정 30T",              "신경·근골격", "ETC사업부",  "대웅제약(자체)", "자체생산", 21, 21),
    ("9305868", "임팩타민 시그니처정 120T",         "OTC·일반",   "CH사업부",   "대웅제약(자체)", "자체생산", 21, 30),
    ("9000126", "임팩타민정 12T",                  "OTC·일반",   "CH사업부",   "대웅제약(자체)", "자체생산", 14, 21),
    ("9000563", "임팩타민 파워정 30T",             "OTC·일반",   "CH사업부",   "대웅제약(자체)", "자체생산", 21, 30),
    ("9000183", "헤모큐플러스캡슐 120C",           "OTC·일반",   "CH사업부",   "위탁생산-국내", "CMO위탁",  30, 30),
    ("7301764", "이지엔6이브 연질캡슐 30CP",        "OTC·일반",   "CH사업부",   "위탁생산-국내", "CMO위탁",  21, 21),
    ("9000029", "이지에프외용액 0.005%",            "OTC·일반",   "ETC사업부",  "대웅제약(자체)", "자체생산", 28, 30),
    ("9306659", "Fexuclue 40mg EC 28T",           "글로벌",      "글로벌사업부","글로벌CMO-A",  "수입",     60, 60),
    ("9311338", "펙수클루정 20mg 100T",            "소화기",      "ETC사업부",  "대웅제약(자체)", "자체생산", 21, 30),
    ("9301924", "리토바젯정 10/40mg 100T",         "순환기",      "ETC사업부",  "종근당",        "국내구매", 14, 21),
    ("7000832", "세비카HCT(5/40/12.5mg) 28T",     "순환기",      "ETC사업부",  "글로벌CMO-B",  "수입",     60, 60),
]

def generate_monthly_data(months_back: int = 6) -> pd.DataFrame:
    """
    월별 PSI(Plan-Sales-Inventory) 샘플 데이터 생성
    실제 운영 시 → load_excel() 함수로 교체
    """
    today = datetime.today().replace(day=1)
    records = []

    for sku_info in SKUS:
        code, name, group, bu, mfg, sup_type, lead_time, safety_days = sku_info

        # 기본 사업계획 (월별 개수)
        base_plan = random.randint(3_000, 80_000)
        base_price = random.choice([6_000, 13_000, 20_000, 48_000, 73_000, 144_000, 221_000])

        # 재고 시나리오 타입
        scenario = random.choices(
            ["normal", "stockout_risk", "excess", "surge"],
            weights=[0.45, 0.25, 0.20, 0.10]
        )[0]

        inv_qty = random.randint(10_000, 300_000)

        for m in range(months_back, -1, -1):
            dt = today - pd.DateOffset(months=m)
            month_str = dt.strftime("%Y-%m")

            # 시나리오별 실제 판매 배율
            if scenario == "stockout_risk":
                actual_ratio = random.uniform(0.02, 0.15)
                supply_ratio = random.uniform(0.3, 0.7)
            elif scenario == "excess":
                actual_ratio = random.uniform(0.05, 0.20)
                supply_ratio = random.uniform(1.5, 3.0)
            elif scenario == "surge":
                actual_ratio = random.uniform(0.8, 1.6) * (1 + m * 0.05)
                supply_ratio = random.uniform(0.8, 1.2)
            else:
                actual_ratio = random.uniform(0.5, 1.1)
                supply_ratio = random.uniform(0.8, 1.2)

            plan_qty   = int(base_plan * random.uniform(0.9, 1.1))
            actual_qty = max(0, int(plan_qty * actual_ratio))
            supply_qty = max(0, int(plan_qty * supply_ratio))

            plan_amt   = plan_qty   * base_price / 1e8   # 억원
            actual_amt = actual_qty * base_price / 1e8
            supply_amt = supply_qty * base_price / 1e8

            beg_inv    = inv_qty
            end_inv    = max(0, beg_inv + supply_qty - actual_qty)
            beg_inv_amt = beg_inv * base_price / 1e8
            end_inv_amt = end_inv * base_price / 1e8

            # 재고일수 (실제 일평균 출하 기준)
            daily_ship  = actual_qty / 30 if actual_qty > 0 else 1
            inv_days    = round(end_inv / daily_ship) if daily_ship > 0 else 999

            # 공급 지연 여부
            delay_days  = 0
            delay_reason = ""
            if scenario == "stockout_risk" and random.random() < 0.5:
                delay_days = random.randint(7, 30)
                delay_reason = random.choice(["생산이슈", "원료부족", "품질검사지연", "통관지연"])

            planned_supply_dt  = (dt + pd.DateOffset(months=1)).strftime("%Y-%m-%d")
            confirmed_supply_dt = (dt + pd.DateOffset(months=1) + timedelta(days=delay_days)).strftime("%Y-%m-%d")

            # 예상 품절일
            if daily_ship > 0 and end_inv > 0:
                stockout_date = (dt + timedelta(days=int(end_inv / daily_ship))).strftime("%Y-%m-%d")
            else:
                stockout_date = month_str + "-01"

            # 리스크 등급
            if inv_days < 20 or delay_days > 14:
                risk_level = "Critical"
            elif inv_days < 30 or delay_days > 0:
                risk_level = "Warning"
            elif inv_days < 60:
                risk_level = "Caution"
            elif inv_days > 120:
                risk_level = "Excess"
            else:
                risk_level = "Stable"

            # 패스트무버/슬로우무버
            fast_mover = (actual_ratio > 1.0 and scenario not in ["excess"])
            slow_mover = (inv_days > 120 or (actual_ratio < 0.3 and scenario == "excess"))

            records.append({
                "date":               month_str,
                "sku_code":           code,
                "product_name":       name,
                "product_group":      group,
                "business_unit":      bu,
                "manufacturer":       mfg,
                "supply_type":        sup_type,
                "lead_time_days":     lead_time,
                "safety_stock_days":  safety_days,
                "plan_qty":           plan_qty,
                "plan_amt":           round(plan_amt, 3),
                "actual_qty":         actual_qty,
                "actual_amt":         round(actual_amt, 3),
                "shipment_qty":       actual_qty,
                "shipment_amt":       round(actual_amt, 3),
                "supply_qty":         supply_qty,
                "supply_amt":         round(supply_amt, 3),
                "beg_inv_qty":        beg_inv,
                "beg_inv_amt":        round(beg_inv_amt, 3),
                "end_inv_qty":        end_inv,
                "end_inv_amt":        round(end_inv_amt, 3),
                "inv_days":           min(inv_days, 999),
                "unit_price":         base_price,
                "channel":            random.choice(CHANNELS),
                "planned_supply_date":   planned_supply_dt,
                "confirmed_supply_date": confirmed_supply_dt,
                "supply_delay_days":     delay_days,
                "supply_delay_reason":   delay_reason,
                "expected_stockout_date": stockout_date,
                "risk_level":         risk_level,
                "fast_mover":         fast_mover,
                "slow_mover":         slow_mover,
                "achievement_rate":   round(actual_amt / plan_amt * 100, 1) if plan_amt > 0 else 0,
                "status_memo":        "",
            })

            # 다음 달 기초재고 = 이번 달 기말재고
            inv_qty = end_inv

    df = pd.DataFrame(records)
    df["date"] = pd.to_datetime(df["date"])
    return df


def get_latest_snapshot(df: pd.DataFrame) -> pd.DataFrame:
    """가장 최근 월 데이터만 추출 (대시보드 메인에서 사용)"""
    latest = df["date"].max()
    return df[df["date"] == latest].copy()


def get_4w_avg(df: pd.DataFrame) -> pd.Series:
    """SKU별 최근 4주 평균 출하 (일평균 × 28)"""
    recent = df.sort_values("date").groupby("sku_code").tail(2)
    return recent.groupby("sku_code")["shipment_qty"].mean() / 30 * 7 * 4


def generate_action_tracker() -> pd.DataFrame:
    """Action Tracker 샘플 데이터"""
    issues = []
    issue_types = ["품절위험", "공급지연", "과잉재고", "수요급증", "판매부진", "생산이슈", "수입·통관이슈", "품질이슈"]
    statuses    = ["Not Started", "In Progress", "Waiting", "Completed", "Delayed"]
    owners      = ["김SCM", "이마케팅", "박구매", "최생산", "정품질"]
    depts       = ["SCM팀", "마케팅팀", "구매팀", "생산팀", "품질팀"]

    for i, sku in enumerate(SKUS[:15]):
        code, name = sku[0], sku[1]
        issues.append({
            "issue_id":    f"ISS-{2026001+i}",
            "sku_code":    code,
            "product_name": name,
            "issue_type":  random.choice(issue_types),
            "risk_level":  random.choice(["Critical", "Warning", "Caution", "Stable"]),
            "action_item": random.choice([
                "공급일정 확인 및 긴급 입고 조율",
                "출하 제한 적용 — 간납 우선 배분",
                "마케팅 매출 상향 요청",
                "추가 생산 오더 발행",
                "원료 수급 현황 확인",
                "수입 통관 일정 확인",
                "품질검사 가속화 요청",
                "월배정 설정 — 종합도매 제한",
            ]),
            "owner":       random.choice(owners),
            "department":  random.choice(depts),
            "due_date":    (datetime.today() + timedelta(days=random.randint(-5, 21))).strftime("%Y-%m-%d"),
            "status":      random.choice(statuses),
            "latest_update": (datetime.today() - timedelta(days=random.randint(0, 7))).strftime("%Y-%m-%d"),
            "next_action": "다음 주 월요일 진척 확인",
        })

    return pd.DataFrame(issues)
